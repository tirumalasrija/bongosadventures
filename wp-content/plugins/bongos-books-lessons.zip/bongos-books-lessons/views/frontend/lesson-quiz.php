<?php if (!empty($quizes)) : ?>

    <script>
        var quizData = <?= json_encode($quizes); ?>;
        var wrongAnswer = <?= json_encode($wrong_answer_message); ?>;
        var correctAnswer = <?= json_encode($correct_answer_message); ?>;
    </script>

    <div id="lesson-quiz" class="quiz-module">
        <div v-for="question, i in quiz.questions">
            <div v-show="i === questionIndex">
                <h2>Quiz</h2>
                <h4>{{ question._bongos_books_lesson_metabox_quiz_question }}</h4>
                <ol>
                    <li v-for="response, j in question._bongos_books_lesson_metabox_quiz_answers">
                        <label>
                            <input type="radio"
                                   v-bind:value="j"
                                   v-bind:name="i"
                                   v-on:click="selected[i] = true"
                                   v-model="userResponses[i]"> {{response._bongos_books_lesson_metabox_quiz_answer_choice}}
                        </label>
                    </li>
                    <div class="question-response" v-show="selected[i]">{{ getAnswerMessage(question, userResponses[i]) }}</div>
                </ol>
                <button v-if="questionIndex > 0" v-on:click="prev">
                    Previous
                </button>
                <button v-on:click="next">
                    Next
                </button>
            </div>
        </div>
        <div v-show="questionIndex === quiz.questions.length">
            <h2>
                Quiz Complete
            </h2>
            <p>
                Your Score: {{ score() }} / {{ quiz.questions.length }}
            </p>
        </div>
    </div>

<?php endif; ?>