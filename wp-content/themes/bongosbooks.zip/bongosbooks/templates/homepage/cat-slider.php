<?php
use TMProd\Base\Assets;

?>

<section class="cat-slider">
    <?php do_shortcode('[bongosbooks_lesson_gallery_filters]') ?>
    <div class="page-wrap">
        <div class="container">
            <?php do_shortcode('[bongosbooks_lesson_gallery]') ?>
        </div>
    </div>
</section>