<p><?php _e( 'Sorry, but the page you were trying to view does not exist.', 'tmbase' ); ?></p>

<div class="panel search-404">
    <div class="panel-body">
        <?php get_search_form(); ?>
    </div>
</div>
