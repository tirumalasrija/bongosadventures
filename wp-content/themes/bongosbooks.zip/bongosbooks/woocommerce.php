<div class="container">
	<?php woocommerce_content(); ?>
</div>