<?php the_content(); ?>

<?php get_template_part( 'templates/pagination' ); ?>