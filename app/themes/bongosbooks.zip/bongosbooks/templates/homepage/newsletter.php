<section class="newsletter">
    <div class="container">
        <h2>Get the latest on the family!</h2>
        <p>Don't miss out on the latest and greatest lessons and adventures the Bongo's family has to offer! Billy, Bella, Jayni, and Jax are waiting for you! Enter your email below to come along for the ride.</p>
        <div class="newsletter-signup">
            <?= do_shortcode('[gravityform id="4" title="false" description="false"]') ?>
        </div>
    </div>
</section>