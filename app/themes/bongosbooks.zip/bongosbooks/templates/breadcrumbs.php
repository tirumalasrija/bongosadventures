<?php
if ( function_exists( 'yoast_breadcrumb' ) ) {
    yoast_breadcrumb( '<p class="breadcrumbs">', '</p>' );
} ?>